create PROCEDURE addUser(
  userName     IN VARCHAR2,
  userPassword IN VARCHAR2,
  email        IN VARCHAR2,
  phone        IN VARCHAR2
)
IS
  cur SYS_REFCURSOR;
  busLine_Id VARCHAR2(20);
  BEGIN
    INSERT INTO busLineManage_user (userId, userName, userPassword, userState, email, phone)
    VALUES (SEQ_UserID.nextval, userName, userPassword, '1', email, phone);
  END;